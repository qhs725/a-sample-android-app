#ifndef SIO_EventTarget_INCLUDED
#define SIO_EventTarget_INCLUDED

#include "Poco/JSON/Array.h"

using Poco::JSON::Array;

class SIOEventTarget
{
private:
	
public:
	virtual ~SIOEventTarget() {};
};
#endif
